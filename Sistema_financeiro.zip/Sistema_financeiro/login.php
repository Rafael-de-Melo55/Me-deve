<?php 
session_start();

include($_SERVER['DOCUMENT_ROOT'] . '/Sistema_financeiro/includes/header.php');

include($_SERVER['DOCUMENT_ROOT'] . '/Sistema_financeiro/data/dados.php');


$mensagem_erro = "";


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nome = $_POST['nome'];
    
    $senha = $_POST['senha'];

    foreach($usuarios as $u){

    if ($u['usuario'] == $nome && $u['senha'] == $senha) {

        header("Location: pages/dashboard.php");
        $_SESSION['usuario_nome'] = $u['usuario'];
        $_SESSION['perfil'] = $u['perfil'];
        exit;

    } else {

        $mensagem_erro = "Usuário ou senha incorretos!";
    }

    }
}
?>

<?php if ($mensagem_erro !== ""): ?>
    <div class="alert alert-danger text-center">
        <?php echo $mensagem_erro; ?>
    </div>
<?php endif; ?>

<div class="card p-4 shadow-sm" style="max-width: 400px; margin: auto;">
    <form method="POST">
        <label class="form-label">Nome:</label>
        <input type="text" name="nome" class="form-control mb-3" required>

        <label class="form-label">Senha:</label>
        <input type="password" name="senha" class="form-control mb-3" required>

        <button type="submit" class="btn btn-primary w-100">Entrar</button>
    </form>
</div>

</body>
</html>
<?php

$usuarios = [
    [
        "usuario" => "caio",
        "senha" => 123,
        "perfil" => "cliente"
    ],
    [
        "usuario" => "laila",
        "senha" => 123,
        "perfil" => "empresa"
    ],
    [
        "usuario" => "rafael",
        "senha" => 123,
        "perfil" => "admin"
    ]
];


$contas = [
    [
        "id" => 1,
        "desc" => "Aluguel da Sede",
        "valor" => 2500.00,
        "vencimento" => "2026-04-10",
        "tipo" => "paga"
    ],
    [
        "id" => 2,
        "desc" => "Energia Elétrica",
        "valor" => 450.75,
        "vencimento" => "2026-04-15",
        "tipo" => "devendo"
    ],
    [
        "id" => 3,
        "desc" => "Internet Fibra",
        "valor" => 199.90,
        "vencimento" => "2026-04-12",
        "tipo" => "paga"
    ],
    [
        "id" => 4,
        "desc" => "Fornecedor de Papelaria",
        "valor" => 850.00,
        "vencimento" => "2026-04-20",
        "tipo" => "devendo"
    ],
    [
        "id" => 5,
        "desc" => "Manutenção Ar-Condicionado",
        "valor" => 320.00,
        "vencimento" => "2026-04-05",
        "tipo" => "atrasada"
    ]
];

$contas2 = [
    [
        "id" => 1,
        "devedor" => "papa francisco",
        "valor" => 150.00,
        "data_emprestimo" => "2026-03-20",
        "status" => "pendente"
    ],
    [
        "id" => 2,
        "devedor" => "Silvo santos",
        "valor" => 500.00,
        "data_emprestimo" => "2026-04-01",
        "status" => "atrasado"
    ],
    [
        "id" => 3,
        "devedor" => "julio cesar",
        "valor" => 80.50,
        "data_emprestimo" => "2026-04-17",
        "status" => "pendente"
    ],
    [
        "id" => 4,
        "devedor" => "pelé",
        "valor" => 1200.00,
        "data_emprestimo" => "2026-02-15",
        "status" => "atrasado"
    ],
    [
        "id" => 5,
        "devedor" => "Ton-618",
        "valor" => 350.00,
        "data_emprestimo" => "2026-04-10",
        "status" => "pago"
    ]
];


?>
<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['contas2'])) {
    include($_SERVER['DOCUMENT_ROOT'] . '/Sistema_financeiro/data/dados.php');
    $_SESSION['contas2'] = isset($contas2) ? $contas2 : [];
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['btn_adicionar'])) {
    $lista_atual = $_SESSION['contas2'];
    $idnovo = (!empty($lista_atual)) ? max(array_column($lista_atual, 'id')) + 1 : 6;

    $coxinha = [
        'id' => $idnovo, 
        'devedor' => $_POST['devedor'],
        'valor' => (float)$_POST['valor'],
        'data_emprestimo' => $_POST['data_emprestimo'],
        'status' => $_POST['status']
    ];

    $_SESSION['contas2'][] = $coxinha;
    
    header("Location: listar.php");
    exit;
}

if (isset($_GET['excluir_id'])) {
    $id_remover = $_GET['excluir_id'];
    $_SESSION['contas2'] = array_filter($_SESSION['contas2'], function($c) use ($id_remover) {
        return $c['id'] != $id_remover;
    });
    header("Location: listar.php");
    exit;
}

include($_SERVER['DOCUMENT_ROOT'] . '/Sistema_financeiro/includes/header.php');
?>

<div class="container mt-5">
    <div class="alert alert-success border-success shadow-sm mb-4">
        <h2 class="m-0">Fluxo Financeiro: Me Deve</h2>
    </div>

    <div class="table-responsive shadow rounded">
        <table class="table table-hover table-bordered border-success mb-0">
            <thead class="table-success border-success">
                <tr class="text-center">
                    <th scope="col">ID</th>
                    <th scope="col">Devedor</th>
                    <th scope="col">Valor</th>
                    <th scope="col">Data Empréstimo</th>
                    <th scope="col">Status</th>
                    <?php if ($_SESSION['perfil'] != 'cliente'): ?>
                        <th scope="col">Ação</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                
                <?php if ($_SESSION['perfil'] != 'cliente'): ?>
                <form action="listar.php" method="POST">
                    <tr class="table-light align-middle">
                        <td class="text-center text-muted">#</td>
                        <td><input type="text" name="devedor" class="form-control form-control-sm border-success" required></td>
                        <td><input type="number" step="0.01" name="valor" class="form-control form-control-sm border-success" required></td>
                        <td><input type="date" name="data_emprestimo" class="form-control form-control-sm border-success" required></td>
                        <td>
                            <select name="status" class="form-select form-select-sm border-success">
                                <option value="pendente">Pendente</option>
                                <option value="pago">Pago</option>
                                <option value="atrasado">Atrasado</option>
                            </select>
                        </td>
                        <td>
                            <button type="submit" name="btn_adicionar" class="btn btn-success btn-sm w-100 shadow-sm">
                                <b>Salvar</b>
                            </button>
                        </td>
                    </tr>
                </form>
                <?php endif; ?>

                <?php 
                foreach ($_SESSION['contas2'] as $c) { 
                    $corBadge = "warning text-dark";
                    if ($c['status'] == 'pago') $corBadge = "success";
                    if ($c['status'] == 'atrasado') $corBadge = "danger";
                ?>
                    <tr class="align-middle text-center">
                        <th scope="row"><?php echo $c['id']; ?></th>
                        <td class="text-start"><?php echo $c['devedor'] ?? '---'; ?></td>
                        <td class="text-success fw-bold">R$ <?php echo number_format($c['valor'] ?? 0, 2, ',', '.'); ?></td>
                        <td><?php echo isset($c['data_emprestimo']) ? date('d/m/Y', strtotime($c['data_emprestimo'])) : '--/--/----'; ?></td>
                        <td>
                            <span class="badge rounded-pill bg-<?php echo $corBadge; ?> px-3">
                                <?php echo ucfirst($c['status'] ?? 'indefinido'); ?>
                            </span>
                        </td>
                        <?php if ($_SESSION['perfil'] != 'cliente'): ?>
                        <td>
                            <a href="listar.php?excluir_id=<?php echo $c['id']; ?>" 
                               class="btn btn-outline-danger btn-sm border-0"
                               onclick="return confirm('Tem certeza rapaiz?')">
                               Excluir
                            </a>
                        </td>
                        <?php endif; ?>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
    
    <div class="mt-4">
        <a href="../dashboard.php" class="btn btn-success">
            Voltar ao Painel
        </a>
    </div>
</div>

</body>
</html>

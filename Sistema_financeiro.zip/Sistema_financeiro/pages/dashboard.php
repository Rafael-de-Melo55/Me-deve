<?php

include($_SERVER['DOCUMENT_ROOT'] . '/Sistema_financeiro/includes/header.php');




?>

<div class="container mt-5">
    <div class="row justify-content-center">
        
        <div class="col-md-4 mb-3">
            <div class="card text-center bg-success text-white shadow">
                <div class="card-body">
                    <h2 class="card-title">Te devo</h2>
                    <p class="card-text">Visualize suas dívidas pendentes.</p>
                    <a href="../pages/contas/listar.php" class="btn btn-light w-100">Ir</a>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-3">
            <div class="card text-center bg-success text-white shadow">
                <div class="card-body">
                    <h2 class="card-title">Me deve</h2>
                    <p class="card-text">Veja quem ainda não te pagou.</p>
                    <a href="../pages/contas/listar2.php" class="btn btn-light w-100">Ir</a>
                </div>
            </div>
        </div>

    </div>
</div>